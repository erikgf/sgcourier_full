<?php
header("Location: login/index.php");