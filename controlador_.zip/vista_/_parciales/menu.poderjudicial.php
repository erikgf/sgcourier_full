<li class="sidebar-item">
    <a class="sidebar-link waves-effect waves-dark" target="_blank" href="../gestionar_poder_judicial/" aria-expanded="false">
        <i class="mdi mdi-view-dashboard"></i><span class="hide-menu"> Gestión Poder Judicial</span>
    </a>
</li>  