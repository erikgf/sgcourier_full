<script src="../../libs/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap tether Core JavaScript -->
<script src="../../libs/popper.js/dist/umd/popper.min.js"></script>
<script src="../../libs/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- slimscrollbar scrollbar JavaScript -->
<script src="../../libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
<script src="../../libs/sparkline/sparkline.js"></script>
<!--Wave Effects -->
<script src="../../js/waves.js"></script>
<!--Menu sidebar -->
<script src="../../js/sidebarmenu.js"></script>
<!--Custom JavaScript -->
<script src="../../js/custom.min.js"></script>