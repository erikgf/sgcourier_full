<li class="sidebar-item">
    <a class="sidebar-link waves-effect waves-dark" target="_blank" href="../consultas/" aria-expanded="false">
        <i class="mdi mdi-view-dashboard"></i><span class="hide-menu"> Consultas</span>
    </a>
    <a class="sidebar-link waves-effect waves-dark" target="_blank" href="../login/index.php" aria-expanded="false">
        <i class="mdi mdi-view-dashboard"></i><span class="hide-menu"> Acceder</span>
    </a>
</li>  