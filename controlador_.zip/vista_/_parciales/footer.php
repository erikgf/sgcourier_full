
<footer class="footer text-center">
	CompuCodex. Copyright <?php echo date("Y") ?><br>
    <small>Matrix-admin. Designed and Developed by <a href="https://wrappixel.com">WrapPixel</a>.</small>
</footer>
<script type="text/javascript">
	var cerrarSesion = function() {
		console.log("close");
	};
</script>