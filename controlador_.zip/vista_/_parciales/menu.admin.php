<li class="sidebar-item">
    <a class="sidebar-link waves-effect waves-dark" href="../agencias/index.agencia.php" aria-expanded="false">
        <i class="mdi mdi-view-dashboard"></i><span class="hide-menu"> Agencias</span>
    </a>
</li>   
<li class="sidebar-item">
    <a class="sidebar-link waves-effect waves-dark" href="../usuarios/index.usuarios.php" aria-expanded="false">
        <i class="mdi mdi-view-dashboard"></i><span class="hide-menu"> Usuarios / Colaboradores</span>
    </a>
</li>
<li class="sidebar-item"> 
	<a class="sidebar-link has-arrow waves-effect waves-dark" href="javascript:void(0)" 
		aria-expanded="false"><i class="mdi mdi-view-dashboard"></i><span class="hide-menu">Pedidos y Órdenes </span>
	</a>
    <ul aria-expanded="false" class="collapse  first-level">
        <li class="sidebar-item">
        	<a href="../gestionar_pedidos/index.leonisa.admin.php" class="sidebar-link"><i class="mdi mdi-account-star"></i>
        		<span class="hide-menu"> LEONISA</span></a>
        </li>
        <li class="sidebar-item">
        	<a href="../gestionar_pedidos/index.leonisa.admin.nuevo.php" class="sidebar-link"><i class="mdi mdi-account-star"></i>
        		<span class="hide-menu"> LEONISA *NUEVO*</span></a>
        </li>
    </ul>
</li>  
<li class="sidebar-item"> 
	<a class="sidebar-link has-arrow waves-effect waves-dark" href="javascript:void(0)" 
		aria-expanded="false"><i class="mdi mdi-view-dashboard"></i><span class="hide-menu">Catálogos</span>
	</a>
    <ul aria-expanded="false" class="collapse  first-level">
        <li class="sidebar-item">
        	<a href="../catalogos/index.leonisa.catalogos.admin.php" class="sidebar-link"><i class="mdi mdi-account-convert"></i>
        		<span class="hide-menu"> LEONISA</span></a>
        </li>
    </ul>
</li>
<li class="sidebar-item">
    <a class="sidebar-link waves-effect waves-dark" href="../consultas_codigo/" aria-expanded="false">
        <i class="mdi mdi-view-dashboard"></i><span class="hide-menu"> Consultas por Código</span>
    </a>
</li> 
<li class="sidebar-item">
    <a class="sidebar-link waves-effect waves-dark" href="../gestionar_poder_judicial/" aria-expanded="false">
        <i class="mdi mdi-view-dashboard"></i><span class="hide-menu"> Gestionar Poder Judicial</span>
    </a>
</li> 
<li class="sidebar-item">
    <a class="sidebar-link waves-effect waves-dark" href="../gestionar_preliquidaciones_admin/" aria-expanded="false">
        <i class="mdi mdi-view-dashboard"></i><span class="hide-menu"> Gestionar Preliquidaciones</span>
    </a>
</li> 
