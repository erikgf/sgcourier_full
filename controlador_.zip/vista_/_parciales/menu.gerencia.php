<li class="sidebar-item">
    <a class="sidebar-link waves-effect waves-dark" href="../agencias/index.agencia.php" aria-expanded="false">
        <i class="mdi mdi-view-dashboard"></i><span class="hide-menu"> Agencias</span>
    </a>
</li>   
<li class="sidebar-item">
    <a class="sidebar-link waves-effect waves-dark" href="../usuarios/index.usuarios.php" aria-expanded="false">
        <i class="mdi mdi-view-dashboard"></i><span class="hide-menu"> Usuarios / Colaboradores</span>
    </a>
</li>
<li class="sidebar-item">
    <a class="sidebar-link waves-effect waves-dark" href="../gestionar_preliquidaciones_admin/" aria-expanded="false">
        <i class="mdi mdi-view-dashboard"></i><span class="hide-menu"> Gestionar Preliquidaciones</span>
    </a>
</li> 