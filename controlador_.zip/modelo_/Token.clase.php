<?php
use Firebase\JWT\JWT;

class Token
{
    private static $secret_key = 'HCI**SOFT500585fijmn@@uhnfijnewr_324';
    private static $encrypt = ['HS256'];
    private static $aud = null;

}
