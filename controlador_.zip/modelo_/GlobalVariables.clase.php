<?php 

class GlobalVariables{
    public static $ID_TIPO_USUARIO_ADMIN = 0;
    public static $ID_TIPO_USUARIO_ADMINISTRATIVO = 1;
    public static $ID_TIPO_USUARIO_EJECUTIVO = 2;
    public static $ID_TIPO_USUARIO_REPARTIDOR = 3;
    public static $ID_TIPO_USUARIO_CLIENTE = 4;

    public static $ID_FUXION_SAC  = 2;
    public static $ID_LEONISA  = 62;
    public static $ID_MINEDU  = 63;

    public static $ID_PRONABEC  = 67;
    public static $ID_PRONIED = 68;

}